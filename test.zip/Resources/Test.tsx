<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Test" tilewidth="30" tileheight="30" spacing="1" margin="1" tilecount="294" columns="21">
 <image source="Test.jpg" width="658" height="454"/>
</tileset>
