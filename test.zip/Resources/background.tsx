<?xml version="1.0" encoding="UTF-8"?>
<tileset name="background" tilewidth="32" tileheight="32" tilecount="280" columns="20">
 <image source="Test.jpg" width="658" height="454"/>
</tileset>
