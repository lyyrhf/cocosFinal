<?xml version="1.0" encoding="UTF-8"?>
<tileset name="back" tilewidth="60" tileheight="60" tilecount="70" columns="10">
 <image source="Test.jpg" width="658" height="454"/>
</tileset>
